/* ============================================================================
 * tools/export_data.c -- dump firmware behaviour as JSON for the visual demo.
 *
 * The animation and the web demo are driven by THIS program's output, so what
 * they show is what bb_beacon.c actually does. Nothing is re-implemented in
 * Python or JavaScript.
 *
 * Emits:
 *   sink[]      depth vs time for a watch sinking in fresh water, 20 Hz
 *   grid[]      for each (bottom depth, threshold, policy): does the beacon
 *               fire, and if so when and at what depth
 *   patterns[]  the flash pattern tables, so the demo blinks in real cadence
 * ==========================================================================*/

#include <stdio.h>
#include "../bb_beacon.h"
#include "../sim_world.h"

#define DT       0.001
#define TICK_MS  10u

/* One descent, sampled for the animation. */
static void emit_sink(double bottom_m)
{
    sim_world_t w;
    sim_defaults(&w);
    w.env.bottom_m  = bottom_m;
    w.env.rho_water = 998.2;

    printf("  \"sink\": {\n");
    printf("    \"dt_s\": 0.05, \"bottom_m\": %.2f,\n", bottom_m);
    printf("    \"release_s\": 2.0,\n");
    printf("    \"depth_m\": [");

    int n = 0;
    for (uint32_t step = 0; step < 60000; step++) {
        double t = step * DT;
        if (!w.released && t >= 2.0) w.released = true;
        sim_step(&w, DT);
        if (step % 50 == 0) {                     /* every 50 ms */
            double d = w.depth_m > 0.0 ? w.depth_m : 0.0;
            printf("%s%.3f", n ? "," : "", d);
            n++;
        }
    }
    printf("],\n    \"samples\": %d\n  },\n", n);
}

/* Does the beacon fire, for this bottom depth / threshold / policy? */
static int probe(double bottom_m, int32_t thr_cm, bb_arm_policy_t pol,
                 double *fire_t, double *fire_d)
{
    sim_world_t w;
    sim_defaults(&w);
    w.env.bottom_m  = bottom_m;
    w.env.rho_water = 998.2;

    bb_config_t cfg;
    bb_config_defaults(&cfg);
    cfg.trigger_depth_cm = thr_cm;
    cfg.water            = BB_WATER_FRESH;
    cfg.arm_policy       = pol;

    bb_ctx_t bb;
    bb_init(&bb, &cfg, 0);
    bb_set_surface_ref(&bb, sim_read_pressure_pa(&w));

    uint32_t next_tick = 0, next_sample = 0;
    for (uint32_t step = 0; step < 90000; step++) {
        double t = step * DT;
        if (!w.released && t >= 2.0) w.released = true;
        sim_step(&w, DT);
        uint32_t now = (uint32_t)(t * 1000.0);

        if (now >= next_sample) {
            next_sample = now + 1000u / bb_sample_rate_hz(&bb);
            bb_on_sample(&bb, now, sim_read_pressure_pa(&w),
                         sim_read_water_contact(&w), sim_read_wrist_on(&w));
        }
        if (now >= next_tick) {
            next_tick = now + TICK_MS;
            bb_on_tick(&bb, now);
        }
        if (bb_is_beaconing(&bb)) { *fire_t = t; *fire_d = w.depth_m; return 1; }
    }
    return 0;
}

int main(void)
{
    printf("{\n");
    printf("  \"_generated_by\": \"tools/export_data.c -- real bb_beacon.c output\",\n");

    emit_sink(12.0);

    /* Flash patterns, so the demo blinks at the real cadence. */
    printf("  \"patterns\": [\n");
    for (int p = 0; p < BB_PATTERN_COUNT; p++) {
        bb_config_t cfg; bb_config_defaults(&cfg);
        cfg.pattern = (bb_pattern_id_t)p;
        cfg.reserve_pattern = (bb_pattern_id_t)p;
        cfg.reserve_brightness_pct = 100;
        cfg.capacity_mah = 105;
        printf("    {\"name\": \"%s\", \"duty_permille\": %u, \"runtime_s\": %u}%s\n",
               bb_pattern_name((bb_pattern_id_t)p),
               bb_pattern_duty_permille((bb_pattern_id_t)p),
               bb_predict_runtime_s(&cfg),
               (p == BB_PATTERN_COUNT - 1) ? "" : ",");
    }
    printf("  ],\n");

    /* Reserve-mode runtimes, default config. */
    bb_config_t d; bb_config_defaults(&d); d.capacity_mah = 105;
    printf("  \"reserve\": {\"pct\": %u, \"pattern\": \"%s\", \"brightness\": %u},\n",
           d.reserve_pct, bb_pattern_name(d.reserve_pattern),
           d.reserve_brightness_pct);

    /* The grid the sliders read from. */
    printf("  \"grid\": [\n");
    int first = 1;
    for (int bi = 5; bi <= 120; bi += 5) {           /* 0.5 m .. 12.0 m */
        double bottom = bi / 10.0;
        for (int thr = 50; thr <= 400; thr += 5) {  /* 50 cm .. 400 cm */
            for (int pol = 0; pol < 2; pol++) {
                double ft = -1, fd = -1;
                int fired = probe(bottom, thr,
                                  pol ? BB_ARM_DEPTH_WRIST_OFF
                                      : BB_ARM_DEPTH_ONLY, &ft, &fd);
                printf("%s    [%.1f,%d,%d,%d,%.2f,%.2f]",
                       first ? "" : ",\n", bottom, thr, pol, fired,
                       fired ? ft : -1.0, fired ? fd : -1.0);
                first = 0;
            }
        }
    }
    printf("\n  ]\n}\n");
    return 0;
}
