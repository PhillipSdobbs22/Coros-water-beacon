/* ============================================================================
 * sim_world.h -- PC-side physics and sensor model.
 *
 * This file is the *test bench*, not firmware.  It is allowed to use
 * floating point, printf, and anything else convenient; none of it ships.
 * The firmware under test (bb_beacon.c) sees only integers.
 * ==========================================================================*/

#ifndef SIM_WORLD_H
#define SIM_WORLD_H

#include <stdbool.h>
#include <stdint.h>

/* --- Watch, as a sinking object -----------------------------------------
 * A 46 mm titanium-and-sapphire watch on a nylon strap.  What matters is
 * that it is denser than water but not by much, and that it tumbles, so
 * it reaches terminal velocity within a metre or so of the surface.
 * ---------------------------------------------------------------------- */
typedef struct {
    double mass_kg;        /* watch + band                                */
    double volume_m3;      /* displaced volume                            */
    double frontal_a_m2;   /* projected area while tumbling               */
    double cd;             /* drag coefficient                            */
} sim_watch_t;

typedef struct {
    double rho_water;      /* kg/m^3                                      */
    double bottom_m;       /* depth of the water column                   */
    double surface_pa;     /* local barometric pressure that day          */
    double baro_noise_pa;  /* +/- peak sensor noise                       */
} sim_env_t;

typedef struct {
    sim_watch_t watch;
    sim_env_t   env;

    double t;              /* seconds                                     */
    double depth_m;        /* positive down; negative == above surface    */
    double v_ms;           /* positive down                               */
    bool   released;       /* strap has failed                            */
    bool   in_water;
    bool   on_bottom;

    uint32_t rng;
} sim_world_t;

void   sim_defaults(sim_world_t *w);
void   sim_step(sim_world_t *w, double dt);

/* Sensor reads, as the firmware would see them. */
int32_t sim_read_pressure_pa(sim_world_t *w);
bool    sim_read_water_contact(const sim_world_t *w);
bool    sim_read_wrist_on(const sim_world_t *w);

#endif
